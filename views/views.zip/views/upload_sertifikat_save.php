<?php
session_start();
error_reporting(0); 
include "../core/koneksi.php";
$namafile = $_FILES['file']['name'];
    if ( $_FILES['file']['error'] > 0 ){
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
        if(move_uploaded_file($_FILES['file']['tmp_name'], '../upload/jaminan/sertifikat/' . $_FILES['file']['name']))
        {
            mysqli_query($con,"update tb_sertifikat set photo ='$namafile' where id_sertifikat='$_SESSION[idsertifikat]'");
			echo "File Uploaded Successfully";
        }
    }

?>
