<?php
session_start();
error_reporting(0); 
include "../core/koneksi.php";
$namafile = $_FILES['file']['name'];
    if ( $_FILES['file']['error'] > 0 ){
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
        if(move_uploaded_file($_FILES['file']['tmp_name'], '../upload/ktp/' . $_FILES['file']['name']))
        {
            mysqli_query($con,"update tb_klien set photo ='$namafile' where id_klien='$_SESSION[idktp]'");
			echo "File Uploaded Successfully";
        }
    }

?>
