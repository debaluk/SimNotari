<?php

?>
<div class="col-md-12">
	<div class="page-header">
		<h1>Dashboard<small> Welcome to Web Panel</small></h1>
	</div>
		<div class="row">
			
		</div>
		<div class="row">
		<div class="panel-body">
									
									<div class="row">
										<div class="col-sm-3">
											<a href="?page=jaminan"><button class="btn btn-icon btn-block">
												<i class="fa fa-tasks"></i>
												Master Jaminan
											</button></a>
										</div>
										<div class="col-sm-3">
											<a href="?page=client"><button class="btn btn-icon btn-block">
												<i class="fa fa-group"></i>
												Master Client
											</button></a>
										</div>
										<div class="col-sm-3">
											<a href="?page=fidusia"><button class="btn btn-icon btn-block">
												<i class="fa fa-list"></i>
												Notariil Jaminan Fidusia
											</button></a>
										</div>
										<div class="col-sm-3">
											<a href="?page=tanggunan"><button class="btn btn-icon btn-block">
												<i class="fa fa-list"></i>
												Notariil Hak Tanggungan
											</button></a>
										</div>
									</div>
									<!--div class="row">
										<div class="col-sm-3">
											<button class="btn btn-icon btn-block">
												<i class="fa fa-picture-o"></i>
												Pictures <span class="badge badge-danger"> 4 </span>
											</button>
										</div>
										<div class="col-sm-3">
											<button class="btn btn-icon btn-block">
												<i class="fa fa-upload"></i>
												Upload <span class="badge badge-success"> 4 </span>
											</button>
										</div>
										<div class="col-sm-3">
											<button class="btn btn-icon btn-block">
												<i class="fa fa-tags"></i>
												Tags <span class="badge badge-danger"> 4 </span>
											</button>
										</div>
									</div>-->
								</div>
			
		</div>
</div>
