<?php
session_start();
error_reporting(0); 
include "../core/koneksi.php";
$namafile = $_FILES['file']['name'];
    if ( $_FILES['file']['error'] > 0 ){
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
        if(move_uploaded_file($_FILES['file']['tmp_name'], '../upload/jaminan/bpkb/' . $_FILES['file']['name']))
        {
            mysqli_query($con,"update tb_bpkb set photo ='$namafile' where id_bpkb='$_SESSION[idbpkb]'");
			echo "File Uploaded Successfully";
        }
    }

?>
