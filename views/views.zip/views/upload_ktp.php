<?php 
session_start();
error_reporting(1);
include "../core/koneksi.php";

$_SESSION[idktp] = $_GET[id];

?>

    <div class="modal-dialog" id="modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title" id="modalAddBrandLabel">Upload KTP</h4>
            </div>
            
				
            	<div class="modal-body"> 
               
                    <div class="form-group">
						<label class="col-sm-3 required">Upload File KTP</label>
						<div class="col-sm-9">
							<input type="file" placeholder="" class="form-control" name="pic" id="pic" required>
						</div>
					</div>
					
					
	            </div>
	              
	            <div class="modal-footer">
	                <button type="button" id="upload" class="btn btn-default">Upload</button> 
	                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>              
	            </div>
            
        </div>
    </div>



<script type="text/javascript">
    $('#upload').on('click', function() {
        var file_data = $('#pic').prop('files')[0];
        var form_data = new FormData(); 
        form_data.append('file', file_data);

        $.ajax({
                url         : 'views/upload_ktp_save.php',   
                dataType    : 'text',           
                cache       : false,
                contentType : false,
                processData : false,
                data        : form_data,                         
                type        : 'post',
                success     : function(output){
                    alert(output);             
					$('#ajaxModal').modal('toggle');                
                    $(".ajaxModal").bind('ajax:complete', function() {$.modal.close();});
                    window.location.reload();
					
                }
         });
         $('#pic').val(''); 
    });
</script>
